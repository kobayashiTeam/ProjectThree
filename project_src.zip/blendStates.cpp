#include"blendStates.h"

bool BlendStates::Initialize(ID3D11Device* device)
{
    HRESULT hr;

    // ====================== None (�u�����h����) ======================
    D3D11_BLEND_DESC noneDesc = {};  // �d�v�F{} �Ń[���N���A
    noneDesc.RenderTarget[0].BlendEnable = FALSE;
    noneDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

    hr = device->CreateBlendState(&noneDesc, m_noneState.GetAddressOf());
    if (FAILED(hr)) return false;

    // ====================== Alpha (�ʏ�̔�����) ======================
    D3D11_BLEND_DESC alphaDesc = {};
    alphaDesc.RenderTarget[0].BlendEnable = TRUE;
    alphaDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    alphaDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    alphaDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    alphaDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    alphaDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    alphaDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    alphaDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

    hr = device->CreateBlendState(&alphaDesc, m_alphaState.GetAddressOf());
    if (FAILED(hr)) return false;

    // ====================== Additive (���̉��Z�Ȃ�) ======================
    D3D11_BLEND_DESC additiveDesc = {};
    additiveDesc.RenderTarget[0].BlendEnable = TRUE;
    additiveDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;        // �� ������ONE�ɕύX
    additiveDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;       // �w�i�ɂ��̂܂ܑ���
    additiveDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;

    additiveDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    additiveDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;  // �܂��� ZERO
    additiveDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;

    additiveDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

    hr = device->CreateBlendState(&additiveDesc, m_additiveState.GetAddressOf());
    if (FAILED(hr))
    {
        // �f�o�b�O�p��hr�̒l���m�F�������ꍇ�͂�����OutputDebugString�Ȃ�
        return false;
    }

    return true;
}

void BlendStates::Bind(ID3D11DeviceContext* context,BlendMode mode) {
	//������ꂽ���[�h�ɉ����ēK�؂ȃX�e�[�g���o�C���h
	switch (mode) {
	case BlendMode::Opaque:
		context->OMSetBlendState(m_noneState.Get(), nullptr, 0xffffffff);
		break;
	case BlendMode::AlphaBlend:
		context->OMSetBlendState(m_alphaState.Get(), nullptr, 0xffffffff);
		break;
	case BlendMode::Additive:
		context->OMSetBlendState(m_additiveState.Get(), nullptr, 0xffffffff);
		break;
	}

	return;
}