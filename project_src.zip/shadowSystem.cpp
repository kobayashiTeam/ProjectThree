#include"shadowSystem.h"
#include"shaderManager.h"

bool ShadowSystem::Initialize(ID3D11Device* pDevice) {

    // ���C�gCB�����i��: 201�s�ځj
    D3D11_BUFFER_DESC bd = {};
    bd.ByteWidth = sizeof(LightBufferCB);
    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    pDevice->CreateBuffer(&bd, nullptr, &m_lightCB);

    // Directional���C�g�����{�V���h�E�}�b�v�i��: 205-236�s�ځj
    DirectionalLight dirLight = {};
    dirLight.type = LightType::Directional;
    dirLight.position = { -3.0f, 5.0f, -10.0f };
    dirLight.direction = { 3.0f, -1.0f, 1.0f };
    dirLight.color = { 1.0f, 1.0f, 1.0f, 1.0f };
    dirLight.intensity = 0.80f;
    m_directionalLights.reserve(MAX_LIGHTS);   // ���|�C���^���S���̂��ߕK�{
    m_directionalLights.push_back(dirLight);

    ShadowMap shadowMap;
    shadowMap.Initialize(pDevice, 2048);
    shadowMap.setLight(&m_directionalLights[0]);
    m_shadowMaps.reserve(MAX_LIGHTS);
    m_shadowMaps.push_back(shadowMap);

    m_shadowShader = ShaderManager::GetInstance().GetShader(ShaderID::Shadow);
    // �V���h�E�T���v���[�����i��: 224-236�s�ځj...
    D3D11_SAMPLER_DESC sampDesc = {};
    sampDesc.Filter = D3D11_FILTER_COMPARISON_MIN_MAG_LINEAR_MIP_POINT;
    sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
    sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
    sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
    sampDesc.BorderColor[0] = 1.0f; // �͈͊O�͉e�Ȃ�
    sampDesc.BorderColor[1] = 1.0f;
    sampDesc.BorderColor[2] = 1.0f;
    sampDesc.BorderColor[3] = 1.0f;
    sampDesc.ComparisonFunc = D3D11_COMPARISON_LESS_EQUAL;

    pDevice->CreateSamplerState(&sampDesc, &m_shadowSampler);

    // Point���C�g�����{�V���h�E�L���[�u�}�b�v�i��: 239-274�s�ځj
    bd = {};
    bd.ByteWidth = sizeof(ShadowCubeCB);
    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    pDevice->CreateBuffer(&bd, nullptr, &m_pointLightCB);

    PointLight pointLight = {};
    pointLight.position = { 5.0f, 5.0f, 3.0f };
    pointLight.color = { 1.0f, 1.0f, 1.0f, 1.0f };
    pointLight.intensity = 1.0f;
    m_pointLights.reserve(MAX_LIGHTS);
    m_pointLights.push_back(pointLight);

    ShadowCubeMap shadowCubeMap;
    shadowCubeMap.Initialize(pDevice, 2048);
    shadowCubeMap.SetLight(&m_pointLights[0]);  // �����R�[�h�̓��[�J���ϐ�pointLight�̃A�h���X��n���Ă������A
    //   ����͊댯�i�֐��𔲂���Ɩ����|�C���^�j�Ȃ̂ŁA
    //   vector���̎��̂��w���悤�C�����Ă����܂�
    m_shadowCubeMaps.reserve(MAX_LIGHTS);
    m_shadowCubeMaps.push_back(shadowCubeMap);

    m_shadowCubeShader = ShaderManager::GetInstance().GetShader(ShaderID::ShadowCube);
    m_shadowCubeGS = ShaderManager::GetInstance().getGS(ShaderID::ShadowCubeGS);
    // �ʏ�T���v���[�����i��: 265-274�s�ځj...
    sampDesc = {};
    sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sampDesc.MinLOD = 0;
    sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
    pDevice->CreateSamplerState(&sampDesc, &m_shadowCubeSampler);

    return true;
}


void ShadowSystem:: UpdateLightDataConstantBuffer(ID3D11DeviceContext* ctx) {

    LightBufferCB cb = {};

    // Directional
    for (int i = 0; i < (int)m_directionalLights.size() && cb.lightCount < MAX_LIGHTS; i++)
    {
        const DirectionalLight& L = m_directionalLights[i];
        auto& dst = cb.lights[cb.lightCount];
        dst.position = { L.position.x, L.position.y, L.position.z, 0.0f };
        dst.direction = { L.direction.x, L.direction.y, L.direction.z, 0.0f };
        dst.color = L.color;
        dst.intensity = L.intensity;
        dst.type = (int)LightType::Directional;
        dst.farPlane = 0.0f;  // ���g�p
        DirectX::XMMATRIX lsm = L.GetViewMatrix() * L.GetProjectionMatrix();
        dst.lightSpaceMatrix = DirectX::XMMatrixTranspose(lsm);
        cb.lightCount++;
    }

    // Point�𑱂��ċl�߂�
    for (int i = 0; i < (int)m_pointLights.size() && cb.lightCount < MAX_LIGHTS; i++)
    {
        const PointLight& L = m_pointLights[i];
        auto& dst = cb.lights[cb.lightCount];
        dst.position = { L.position.x, L.position.y, L.position.z, 0.0f };
        dst.color = L.color;
        dst.intensity = L.intensity;
        dst.type = (int)LightType::Point;
        dst.farPlane = L.farPlane;
        // lightSpaceMatrix�͖��g�p�Ȃ̂Ń[���̂܂�
        cb.lightCount++;
    }

    ctx->UpdateSubresource(m_lightCB.Get(), 0, nullptr, &cb, 0, 0);

    ID3D11Buffer* cbArray[] = { m_lightCB.Get() };
    ctx->VSSetConstantBuffers(3, 1, cbArray);
    ctx->PSSetConstantBuffers(3, 1, cbArray);
}


void ShadowSystem::UpdatePointLightConstantBuffer(ID3D11DeviceContext* ctx) {

    if (m_pointLights.empty()) return;

    ShadowCubeCB cb = {};
    const PointLight& L = m_pointLights[0];  // ����1���Œ�

    cb.gLightPos = L.position;
    cb.gFarPlane = L.farPlane;

    // 6�ʕ���ViewProj�s��
    DirectX::XMMATRIX proj = L.GetProjectionMatrix();
    for (int i = 0; i < 6; i++)
    {
        DirectX::XMMATRIX vp = L.GetViewMatrix(i) * proj;
        cb.gLightViewProj[i] = DirectX::XMMatrixTranspose(vp);
    }

    ctx->UpdateSubresource(m_pointLightCB.Get(), 0, nullptr, &cb, 0, 0);

    ID3D11Buffer* cbArray[] = { m_pointLightCB.Get() };
    ctx->VSSetConstantBuffers(4, 1, cbArray);
    ctx->GSSetConstantBuffers(4, 1, cbArray);  // GS�ɂ��Y�ꂸ
    ctx->PSSetConstantBuffers(4, 1, cbArray);
}