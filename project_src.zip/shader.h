// Shader.h
#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>

class Shader {
private:
    ID3D11VertexShader* m_pVertexShader = nullptr;
    ID3D11PixelShader* m_pPixelShader = nullptr;
    ID3D11InputLayout* m_pVertexLayout = nullptr;
    //test:geometry
    ID3D11GeometryShader* m_pGeometryShader = nullptr;

public:
    Shader() = default;
    ~Shader() { Cleanup(); }

    // �������\�b�h
    bool Create(ID3D11Device* pDevice, 
        const wchar_t* vsFileName, 
        const wchar_t* psFileName,
        const D3D11_INPUT_ELEMENT_DESC* layout,  // �ǉ�
        UINT layoutCount                          // �ǉ�)
        );

    // ���p�i�o�C���h�j���\�b�h
    void Bind(ID3D11DeviceContext* pContext);

    void Cleanup();

    //test:geomtry
    void SetGS(ID3D11GeometryShader* gs) { m_pGeometryShader = gs; }
};