#pragma once

#include<d3d11.h>
#include<DirectXMath.h>
#include<wrl/client.h>

template<typename T> using ComPtr = Microsoft::WRL::ComPtr<T>;

//forward
class DirectionalLight;

class ShadowMap {
public:
    void Initialize(ID3D11Device* device, UINT size);
    void BeginRender(ID3D11DeviceContext* ctx);   // �p�X1�̊J�n
    void EndRender(ID3D11DeviceContext* ctx);

    ID3D11ShaderResourceView* GetSRV() const { return m_srv.Get(); }    // �p�X2�ŃV�F�[�_�ɓn��
    DirectX::XMMATRIX GetLightSpaceMatrix() const;         // cbuffer�ɓn���s��
    void setLight(DirectionalLight* light) { m_pLight = light; }

private:
    ComPtr<ID3D11Texture2D>          m_texture;
    ComPtr<ID3D11DepthStencilView>   m_dsv;
    ComPtr<ID3D11ShaderResourceView> m_srv;
    const DirectionalLight* m_pLight;  // �O����󂯎��i���L���Ȃ��j
    UINT m_size;
};