#include"outLine.h"
#include"model.h"

OutLine::OutLine() {
}

OutLine::~OutLine() {
	if (m_pNormalStencilState) {
		m_pNormalStencilState->Release();
		m_pNormalStencilState = nullptr;
	}
	if (m_pOutlineStencilState) {
		m_pOutlineStencilState->Release();
		m_pOutlineStencilState = nullptr;
	}
	m_pOutlineMaterial = nullptr; // �}�e���A���͊O���ŊǗ�����Ă���̂ŁA�����ł̓����[�X���Ȃ�
}

bool OutLine::createStencilState(ID3D11Device* pDevice, ID3D11DeviceContext* context) {

    HRESULT hr;
    //�������ݗp�X�e�[�g
    D3D11_DEPTH_STENCIL_DESC normalStencilDesc = {};
    normalStencilDesc.DepthEnable = TRUE;
    normalStencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    normalStencilDesc.DepthFunc = D3D11_COMPARISON_LESS;

    normalStencilDesc.StencilEnable = TRUE;
    normalStencilDesc.StencilReadMask = 0xFF;
    normalStencilDesc.StencilWriteMask = 0xFF;

    // �O�ʁE�w�ʂƂ������ݒ��OK�i�V���v���Ɂj
    normalStencilDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    normalStencilDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
    normalStencilDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_REPLACE;  // �d�v
    normalStencilDesc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

    normalStencilDesc.BackFace = normalStencilDesc.FrontFace;  // �����ݒ�

    hr = pDevice->CreateDepthStencilState(&normalStencilDesc, &m_pNormalStencilState);
    if (FAILED(hr)) return false;

    //�ǂݍ��ݗp�X�e�[�g
    D3D11_DEPTH_STENCIL_DESC outlineStencilDesc = {};
    outlineStencilDesc.DepthEnable = FALSE;           // �d�v�F�[�x�e�X�g����
    outlineStencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
    outlineStencilDesc.StencilEnable = TRUE;
    outlineStencilDesc.StencilReadMask = 0xFF;
    outlineStencilDesc.StencilWriteMask = 0x00;       // �������݂͂��Ȃ�

    outlineStencilDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    outlineStencilDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
    outlineStencilDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    outlineStencilDesc.FrontFace.StencilFunc =
        static_cast<D3D11_COMPARISON_FUNC>(D3D11_COMPARISON_NOT_EQUAL);;  // 1�ȊO�Ȃ�`��

    outlineStencilDesc.BackFace = outlineStencilDesc.FrontFace;

    pDevice->CreateDepthStencilState(&outlineStencilDesc, &m_pOutlineStencilState);

    return true;
}

void OutLine::DrawOutline(ID3D11DeviceContext* pContext, Model* pModel, ID3D11Buffer* pCB) {

    // === Pass 1 ===
    pContext->OMSetDepthStencilState(m_pNormalStencilState, 1);
    pModel->SetScale(1.0f, 1.0f, 1.0f);
    pModel->Draw(pContext, pCB);

    // === Pass 2 ===
    pContext->OMSetDepthStencilState(m_pOutlineStencilState, 1);
    pModel->SetScale(1.2f, 1.2f, 1.2f);
    pModel->DrawWithOutLine(pContext, pCB,m_pOutlineMaterial);

    // === ��Еt�� ===
    pModel->SetScale(1.0f, 1.0f, 1.0f);
}